import { useEffect, useState } from "react";

const images = {
  hero: "https://images.unsplash.com/photo-1726161375655-9a0140abd320?auto=format&fit=crop&w=2000&q=88",
  chicken: "https://images.unsplash.com/photo-1709164632728-8a943456dd0a?auto=format&fit=crop&w=1200&q=85",
  toast: "https://images.unsplash.com/photo-1687184743580-7f78491ff7b3?auto=format&fit=crop&w=1000&q=85",
  ravioli: "https://images.unsplash.com/photo-1778850620699-79ba3ff60bf0?auto=format&fit=crop&w=1000&q=85",
  pork: "https://images.unsplash.com/photo-1625477811233-044633d10dd1?auto=format&fit=crop&w=1000&q=85",
  matcha: "https://images.unsplash.com/photo-1749104953222-9d6ed76e4bf0?auto=format&fit=crop&w=1000&q=85",
  table: "https://images.unsplash.com/photo-1734529300657-78f9a06f2bcd?auto=format&fit=crop&w=1200&q=85",
  interior: "https://images.unsplash.com/photo-1648808694138-6706c5efc80a?auto=format&fit=crop&w=1400&q=85",
  lights: "https://images.unsplash.com/photo-1764175761426-d45812365326?auto=format&fit=crop&w=1000&q=85",
  patio: "https://images.unsplash.com/photo-1544456203-9e84b31c8cb9?auto=format&fit=crop&w=1200&q=85",
};

const events = [
  { day: "MON", date: "16", title: "CLOSED FOR MISCHIEF", note: "We’ll be back tomorrow", kind: "plain" },
  { day: "TUE", date: "17", title: "STUDENT SOCIAL", note: "Offer to be announced", kind: "image", image: images.interior },
  { day: "WED", date: "18", title: "MIDWEEK MATCHA", note: "Special pour from 4 PM", kind: "plain" },
  { day: "THU", date: "19", title: "THE LISTENING TABLE", note: "Bring one song you love", kind: "image", image: images.lights },
  { day: "FRI", date: "20", title: "FRIDAY AFTER DARK", note: "Reservations recommended", kind: "dark" },
  { day: "SAT", date: "21", title: "BRUNCH, BABY", note: "All day. No rush.", kind: "image", image: images.toast },
  { day: "SUN", date: "22", title: "SUNDAY SOFT LAUNCH", note: "Offer to be announced", kind: "plain" },
];

const menu = [
  ["CRUNCH", "Korean Fried Chicken", "Gochujang glaze, sesame, scallion"],
  ["COMFORT", "Sticky Pork Belly", "Slow-cooked, chilli caramel, pickles"],
  ["PASTA", "Blush Pink Ravioli", "Ricotta, beet cream, brown butter"],
  ["SWEET", "Brioche French Toast", "Berries, cream, maple"],
  ["POUR", "Ceremonial Matcha", "Hot, iced, or strawberry cloud"],
  ["LATE", "Burnt Basque Slice", "Sea salt, seasonal compote"],
];

function Arrow() {
  return <span aria-hidden="true">↗</span>;
}

export default function App() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <main>
      <header className="hero" id="top">
        <img className="hero-image" src={images.hero} alt="Evening café mood with guests and warm outdoor lighting" />
        <div className="hero-shade" />
        <nav className={`nav ${scrolled ? "nav-scrolled" : ""} ${menuOpen ? "nav-open" : ""}`} aria-label="Main navigation">
          <a className="brand" href="#top" onClick={closeMenu}>BUNS N’ ROSES</a>
          <div className="nav-links">
            <a href="#cafe">The café</a>
            <a href="#menu">The menu</a>
            <a href="#vibe">The vibe</a>
            <a href="#bulletin">What’s on</a>
            <a href="#visit">Find us</a>
          </div>
          <a className="nav-book" href="#visit">Book a table <Arrow /></a>
          <button className="menu-toggle" type="button" onClick={() => setMenuOpen((open) => !open)} aria-expanded={menuOpen} aria-label="Toggle navigation">
            {menuOpen ? "Close" : "Menu"}
          </button>
          <div className="mobile-menu">
            {[
              ["The café", "#cafe"],
              ["The menu", "#menu"],
              ["The vibe", "#vibe"],
              ["What’s on", "#bulletin"],
              ["Find us", "#visit"],
            ].map(([label, href]) => <a key={href} href={href} onClick={closeMenu}>{label}</a>)}
          </div>
        </nav>
        <div className="hero-copy">
          <p className="eyebrow">SEMBAKKAM · CHENNAI · TAMIL NADU</p>
          <h1>GOOD FOOD.<br />BETTER VIBES.<br /><em>A LITTLE WILD.</em></h1>
          <div className="hero-bottom">
            <p>An unexpected little escape in Sembakkam. Come hungry, stay for the vibe.</p>
            <div className="hero-actions">
              <a className="button button-light" href="#menu">Explore the menu <Arrow /></a>
              <a className="button button-line" href="#visit">Find your table <Arrow /></a>
            </div>
          </div>
        </div>
        <div className="hero-meta"><span>SEMBAKKAM, CHENNAI</span><span>GOOD FOOD · GREEN CORNERS · GOOD COMPANY</span></div>
        <a className="scroll-cue" href="#story"><span>Scroll</span><i /></a>
        <p className="image-disclaimer">Editorial mood image — venue photography to be supplied</p>
      </header>

      <section className="ticker" aria-label="Highlights">
        <div>BRUNCH ALL DAY <b>✳</b> PET FRIENDLY <b>✳</b> MATCHA, ALWAYS <b>✳</b> SEMBAKKAM’S WILDEST TABLE <b>✳</b></div>
      </section>

      <section className="masthead" id="story">
        <div className="mast-meta">
          <span>INDEPENDENTLY SERVED IN CHENNAI</span>
          <span>MADE IN CHENNAI</span>
        </div>
        <h2>BUNS N’<br /><span>ROSES</span></h2>
        <p className="culture-club">CAFÉ CULTURE CLUB / ISSUE NO. 001</p>
        <div className="manifesto">
          <p className="manifesto-lead">Not your quiet corner café.</p>
          <p>Good plates, green corners, long conversations, and absolutely no reason to rush home.</p>
          <a href="#visit">Meet us in Sembakkam <Arrow /></a>
        </div>
        <div className="mast-strip">
          <figure><img src={images.interior} alt="Editorial mood reference of a light-filled café" /><figcaption>01 / THE ROOM</figcaption></figure>
          <figure><img src={images.chicken} alt="Fried chicken and fries on a wooden plate" /><figcaption>02 / THE PLATE</figcaption></figure>
          <figure><img src={images.patio} alt="Friends seated at an outdoor café table" /><figcaption>03 / THE HANG</figcaption></figure>
        </div>
      </section>

      <section className="food-editorial" id="cafe" aria-label="Food highlights">
        <div className="food-heading"><span>THE EDIT / PLATES WORTH PAUSING FOR</span><h2>WHAT’S<br />GOOD HERE?</h2></div>
        <article className="feature feature-main">
          <div className="photo-frame">
            <img src={images.chicken} alt="Crispy fried chicken and fries served on a wooden plate" />
            <span className="photo-index">01 / CRUNCH</span>
          </div>
          <div className="feature-caption">
            <h3>KOREAN<br />FRIED<br />CHICKEN</h3>
            <p>Shatter-crisp. Sticky-sweet.<br />Absolutely no clean shirts.</p>
          </div>
        </article>
        <article className="feature feature-small">
          <div className="photo-frame"><img src={images.toast} alt="French toast topped with berries" /></div>
          <div className="feature-row"><span>02 / SOFT</span><h3>FRENCH TOAST</h3></div>
        </article>
        <article className="feature feature-tall">
          <div className="photo-frame"><img src={images.ravioli} alt="Ravioli with tomatoes, sage, and parmesan" /></div>
          <div className="feature-row"><span>03 / PINK</span><h3>RAVIOLI</h3></div>
        </article>
        <article className="feature feature-pork">
          <div className="photo-frame"><img src={images.pork} alt="Glazed pork belly presented on a restaurant plate" /></div>
          <div className="feature-row"><span>04 / STICKY</span><h3>PORK BELLY</h3></div>
        </article>
        <article className="feature feature-matcha">
          <div className="matcha-copy"><span>05 / POUR</span><h3>GREEN<br />FLAG<br />ENERGY.</h3><p>Ceremonial matcha, whisked to order.</p></div>
          <img src={images.matcha} alt="Matcha latte with foam art" />
        </article>
        <a className="full-menu-link" href="#menu">View the full menu <Arrow /></a>
      </section>

      <section className="bulletin" id="bulletin">
        <div className="section-heading">
          <p>VOL. 01 / EDITABLE PLACEHOLDER SCHEDULE</p>
          <h2>INSTAGRAM<br /><em>BULLETIN</em></h2>
          <span>Save it. Send it.<br />Show up hungry.</span>
        </div>
        <div className="calendar">
          {events.map((event) => (
            <article className={`event event-${event.kind}`} key={event.day} style={event.image ? { backgroundImage: `linear-gradient(0deg, rgba(0,0,0,.7), rgba(0,0,0,.08)), url(${event.image})` } : undefined}>
              <div className="event-date"><span>{event.day}</span><strong>{event.date}</strong></div>
              <div className="event-copy"><h3>{event.title}</h3><p>{event.note}</p></div>
            </article>
          ))}
        </div>
        <div className="promo-strip">
          <span>WEEKLY DROP</span>
          <strong>NEW PLATES. NEW PLANS. SAME TABLE.</strong>
          <a href="https://www.instagram.com/" target="_blank" rel="noreferrer">Follow the updates <Arrow /></a>
        </div>
      </section>

      <section className="menu-section" id="menu">
        <div className="menu-intro">
          <p className="eyebrow">THE SHORT LIST / 2025</p>
          <h2>COME<br />HUNGRY.</h2>
          <p>Big comfort, bright flavour, and zero commitment to one cuisine. Here are a few house favourites.</p>
          <a className="button button-dark" href="#visit">View full menu <Arrow /></a>
        </div>
        <div className="menu-list">
          {menu.map(([tag, name, description], index) => (
            <div className="menu-item" key={name}>
              <span>{String(index + 1).padStart(2, "0")}</span>
              <div><small>{tag}</small><h3>{name}</h3><p>{description}</p></div>
              <b>↗</b>
            </div>
          ))}
        </div>
      </section>

      <section className="gallery" id="vibe" aria-label="Café ambience">
        <div className="gallery-title"><span>THE CAFÉ IS THE MAIN CHARACTER</span><h2>NOT JUST A<br />PLACE TO EAT.</h2><p>Your new favourite little corner.</p></div>
        <figure className="gallery-wide"><img src={images.interior} alt="Bright modern café interior with wooden tables" /><figcaption>GOOD LIGHT, BETTER COMPANY</figcaption></figure>
        <figure className="gallery-portrait"><img src={images.lights} alt="Warm pendant lights surrounded by indoor greenery" /><figcaption>AFTER 6 PM</figcaption></figure>
        <figure className="gallery-square"><img src={images.patio} alt="Friends talking at an outdoor café table" /><figcaption>TABLE FOR EVERYONE</figcaption></figure>
      </section>

      <section className="about">
        <div className="about-image"><img src={images.table} alt="A café table set with brunch plates and coffee" /><span>EDITORIAL MOOD IMAGE / REPLACE WITH VENUE ORIGINAL</span></div>
        <div className="about-copy">
          <p className="eyebrow">A LITTLE MORE ABOUT US</p>
          <h2>COME FOR<br />THE FOOD.<br /><em>STAY FOR<br />EVERYTHING ELSE.</em></h2>
          <p>Buns n’ Roses is imagined as the kind of neighbourhood corner where interesting plates meet leafy spaces and easy conversation. This space is reserved for the owners’ official story—told in their own words.</p>
        </div>
      </section>

      <section className="visit" id="visit">
        <div className="visit-title">
          <p>FIND YOUR CORNER</p>
          <h2>SEE YOU<br />AT THE<br /><em>CAFÉ?</em></h2>
        </div>
        <div className="visit-details">
          <div><span>ADDRESS</span><p>Buns n’ Roses<br />Sembakkam, Chennai</p><small>Street address awaiting verification</small><span className="disabled-link">Get directions — coming soon</span></div>
          <div><span>HOURS</span><p>Opening hours<br />to be confirmed</p><small>Owner-supplied details will appear here</small></div>
          <div><span>PLAN A VISIT</span><p>Contact number and booking method awaiting confirmation.</p><div className="visit-actions"><a href="#menu">View menu <Arrow /></a><span className="disabled-link">Book a table — coming soon</span></div></div>
        </div>
      </section>

      <footer>
        <div className="footer-logo">BUNS N’ ROSES</div>
        <div className="footer-statement">GOOD FOOD. GOOD PEOPLE. SEE YOU SOON.</div>
        <div className="footer-bottom"><span>SEMBAKKAM / CHENNAI</span><span>© 2025 BUNS N’ ROSES</span><a href="#top">BACK TO TOP ↑</a></div>
      </footer>
    </main>
  );
}
